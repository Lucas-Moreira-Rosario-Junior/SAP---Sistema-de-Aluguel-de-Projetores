<html>
  <head>
    <link href="./css/smoothness/jquery-ui-1.10.3.custom.css" rel="stylesheet" type="text/css" />
	<link href="./themes/lightcolor/blue/jtable.css" rel="stylesheet" type="text/css" />
	
	<script src="./js/jquery-1.9.1.js" type="text/javascript"></script>
    <script src="./js/jquery-ui-1.10.3.custom.js" type="text/javascript"></script>
    <script src="jquery.jtable.js" type="text/javascript"></script>
	
  </head>
  <body>
  <h2>
  <center>
  Javascript Ajax Grid Table
  </center>
  </h2>
	<center><div id="estudanteTableContainer" style="width: 1000px;"></div></center>
	<script type="text/javascript">

		$(document).ready(function () {
			$('#estudanteTableContainer').jtable({
				title: 'Lista de Estudantes', // titulo da tabela na visualizacao
				actions: {
					listAction: 'estudanteDAO.php?action=list',
					createAction: 'estudanteDAO.php?action=create',
					updateAction: 'estudanteDAO.php?action=update',
					deleteAction: 'estudanteDAO.php?action=delete'
				},
				fields: {
					id: {
						key: true,
						create: false,
						edit: false,
						list: true,
						width: '10%',
						title: 'ID'
					},
					nome: {
						title: 'Nome do estudante',
						width: '60%'
					},
					idade: {
						title: 'Idade do estudante',
						width: '30%'
					}
				}
			});

				$('#estudanteTableContainer').jtable('load');

		});

	</script>

 
  </body>
</html>
